//
//  fifthview.swift
//  ListenUp
//
//  Created by vijjuajay on 12/6/20.
//

import SwiftUI

struct fifthview: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct fifthview_Previews: PreviewProvider {
    static var previews: some View {
        fifthview()
    }
}
